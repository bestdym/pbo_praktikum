// Subkelas kreatif turunan dari Mahasiswa khusus untuk jurusan Informatika
public class MahasiswaInformatika extends Mahasiswa {
    private String peminatan;
    private String bahasaPemrogramanFavorit;

    public MahasiswaInformatika(String nama, String email, String nim, double ipk, String peminatan, String bahasaPemrogramanFavorit) {
        super(nama, email, nim, ipk); // Memanggil constructor kelas Mahasiswa
        this.peminatan = peminatan;
        this.bahasaPemrogramanFavorit = bahasaPemrogramanFavorit;
    }

    @Override
    public void tampilkanInfo() {
        System.out.println(">>> MAHASISWA INFORMATIKA <<<");
        super.tampilkanInfo(); // Menampilkan info dasar (Nama, Email, NIM, IPK) dari kelas Mahasiswa
        System.out.println("Peminatan            : " + peminatan);
        System.out.println("Bahasa Pemrograman   : " + bahasaPemrogramanFavorit);
        System.out.println("==============================");
    }
}